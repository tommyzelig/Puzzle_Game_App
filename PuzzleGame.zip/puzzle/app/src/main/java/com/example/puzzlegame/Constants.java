package com.example.puzzlegame;

public class Constants {

    public static final int EASY = 1;
    public static final int MED = 2;
    public static final int HARD = 3;

    public static final String MSG = "MSG";

}
